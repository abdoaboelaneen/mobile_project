import 'dart:async';
import 'package:flutter/material.dart';
import 'package:newwwww/google_maps.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:geolocator/geolocator.dart';

void main() {
  runApp(AccidentDetectionApp());
}

class AccidentDetectionApp extends StatefulWidget {
  @override
  _AccidentDetectionAppState createState() => _AccidentDetectionAppState();
}

class _AccidentDetectionAppState extends State<AccidentDetectionApp> {
  bool _isAccidentDetected = false;
  AccelerometerEvent? _accelerometerEvent;
  GyroscopeEvent? _gyroscopeEvent;
  Position? position;
  String time = '';
  StreamSubscription<AccelerometerEvent>? _accelerometerSubscription;
  StreamSubscription<GyroscopeEvent>? _gyroscopeSubscription;

  @override
  void initState() {
    super.initState();
    _startListening();
  }

  void location() async {
    position = await Geolocator.getCurrentPosition();
  }

  @override
  void dispose() {
    //_stopListening();
    super.dispose();
  }

  void _startListening() {
    _accelerometerSubscription =
        accelerometerEvents.listen((AccelerometerEvent event) {
      setState(() {
        _accelerometerEvent = event;
      });
      _detectAccident();
    });

    _gyroscopeSubscription = gyroscopeEvents.listen((GyroscopeEvent event) {
      setState(() {
        _gyroscopeEvent = event;
      });
      _detectAccident();
    });
  }

  void _stopListening() {
    _accelerometerSubscription?.cancel();
    _gyroscopeSubscription?.cancel();
  }

  void _detectAccident() async {
    if (_accelerometerEvent != null && _gyroscopeEvent != null) {
      // Perform accident detection logic here
      // Example: Check if the accelerometer or gyroscope readings exceed a threshold

      if (_accelerometerEvent!.x > 20 ||
          _gyroscopeEvent!.x > 25 ||
          _accelerometerEvent!.y > 20 ||
          _gyroscopeEvent!.y > 25 ||
          _accelerometerEvent!.z > 20 ||
          _gyroscopeEvent!.z > 25) {
        setState(() {
          _isAccidentDetected = true;
          location();
          time = DateTime.now().toString();
        });
        print(
            'Accident detected at: {position.latitude}, {position.longitude}');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Accident Detection Application '),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Is there an accident ?',
                style: TextStyle(fontSize: 35),
              ),
              Text(
                _isAccidentDetected ? 'Yes' : 'No',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: _isAccidentDetected ? Color(0xff9d0a0a) : Colors.green,
                ),
              ),
              Text(
                position == null ? '' : 'Time:$time',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: _isAccidentDetected ? Color(0xff252323) : Colors.green,
                ),
              ),
              Text(
                position == null ? '' : 'Longitude:${position!.longitude}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: _isAccidentDetected ? Color(0xff252323) : Colors.green,
                ),
              ),
              Text(
                position == null ? '' : 'Latitude:${position!.latitude}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: _isAccidentDetected ? Color(0xff252323) : Colors.green,
                ),
              ),
              ElevatedButton(
                onPressed: () async {
                  print('abdo');
                  if (position != null) {
                    print('mklml');
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MapScreen(
                          latitude: position!.latitude,
                          longitude: position!.longitude,
                        ),
                      ),
                    );
                  } else {
                    // If the position is not yet available, display a message to the user
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Location not available yet"),
                      ),
                    );
                  }
                },
                child: Text('Location To Map'),
              ),
              if (_isAccidentDetected)
                ElevatedButton(
                  child: Text('Retry'),
                  onPressed: () {
                    _startListening();
                    setState(() {
                      _isAccidentDetected = false;
                      position = null;
                      time = '';
                    });
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}
