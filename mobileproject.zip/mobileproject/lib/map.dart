import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Map Example',
      home: MapScreen(),
    );
  }
}

class MapScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final LatLng center = LatLng(29.307652, 30.846704);
    final LatLng swPanBoundary = LatLng(29.2691, 30.8062);
    final LatLng nePanBoundary = LatLng(29.3429, 30.8818);

    final markers = <Marker>[
      Marker(
        point: LatLng(29.307652, 30.846704),
        builder: (context) => const Icon(
          Icons.wrong_location_rounded,
          color: Colors.green,
          size: 35.0,
        ),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text('Map Example'),
      ),
      body: FlutterMap(
        options: MapOptions(
          center: center,
          swPanBoundary: swPanBoundary,
          nePanBoundary: nePanBoundary,
        ),
        layers: [
          TileLayerOptions(
            tileProvider: AssetTileProvider(),
            urlTemplate: 'Fayom/{z}/{x}/{y}.png',
          ),
          MarkerLayerOptions(markers: markers),
        ],
      ),
    );
  }
}
